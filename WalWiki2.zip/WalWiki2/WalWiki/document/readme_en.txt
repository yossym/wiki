#
# wiki.cgi - YukiWiki, a Wiki clone.
#
# Copyright (C) 2000-2002 by Hiroshi Yuki.
# <hyuki@hyuki.com>
# http://www.hyuki.com/yukiwiki/
#
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.

FILES

 README

    +-- readme_en.txt                              README (English).
    +-- readme_ja.txt                              README (Japanese).
    +-- wikiman_ja.pl                              MANUAL (Japanese).
    +-- history1.txt                               Change History (YukiWiki1)
    +-- history2.txt                               Change History (YukiWiki2)

 CGI

    +-- convert.cgi     TEXT      755 (rwxr-xr-x)  YukiWiki1->2 converter.
    +-- wiki.cgi        TEXT      755 (rwxr-xr-x)  YukiWiki itself.
    +-- jcode.pl        TEXT      644 (rw-r--r--)  Japanese code converter.
    +-- Yuki                      755 (rwxr-xr-x)  directory
    |   +-- YukiWikiDB.pm   TEXT  644 (rw-r--r--)  file based DB.
    |   +-- RSS.pm      TEXT      644 (rw-r--r--)  small RSS.
    |   +-- DiffText.pm TEXT      644 (rw-r--r--)  Algorithm::Diff wrapper.
    +-- Algorithm                 755 (rwxr-xr-x)  directory.
        +-- Diff.pm     TEXT      644 (rw-r--r--)  diff module (by Ned Konz).

 DATA FILES

    You must FTP the following files to $modifier_dir_data.
    $modifier_dir_data is in wiki.cgi.

    +-- touched.txt     TEXT      666 (rw-rw-rw-)  touch file.
    +-- frontpage.txt   TEXT      644 (rw-r--r--)  text for 'FrontPage'.
    +-- resource.txt    TEXT      644 (rw-r--r--)  resource file.
    +-- conflict.txt    TEXT      644 (rw-r--r--)  text for conflict notice.
    +-- format.txt      TEXT      644 (rw-r--r--)  text for format rule.

 CSS AND IMAGE FILES

    You must FTP the following files to $modifier_url_data.
    $modifier_url_data is in wiki.cgi.

    +-- wiki.css        TEXT      644 (rw-r--r--)  stylesheet.
    +-- icon40x40.gif   BINARY    644 (rw-r--r--)  small icon.
    +-- icon80x80.gif   BINARY    644 (rw-r--r--)  large icon.

INSTALL

  (1) Modify the first line of 'wiki.cgi'

      #!/usr/local/bin/perl

  (2) Modify $modifier_... variable in 'wiki.cgi'. (MUST)

      my $modifier_mail       your mail address.
      my $modifier_url        your web page.
      my $modifier_name       your name.
      my $modifier_dbtype     database type (one of the followings).
          'AnyDBMFile'
          'dbmopen'
          'YukiWikiDB'

      my $modifier_sendmail   sendmail command line.
          '/usr/sbin/sendmail -t -n'      (for example)
          ''                              (if you do not need notification)

      my $modifier_dir_data   your data directory.
          '.' (default)

      my $modifier_url_data   your data url.
          '.' (default)

      my $modifier_rss_title          RSS title
      my $modifier_rss_link           RSS link (your wiki's URL)
      my $modifier_rss_description    your wiki's description.

    (3) FTP all files in FILES section.

    (4) (only for YukiWiki1 users) Convert YukiWiki1 data.
    
      (a) Access 'convert.cgi' with your browser.
      (b) Convert the data according to the form.
      (c) Wait for a while.

    (5) Be sure to delete 'convert.cgi' for security.

    (6) Access your 'wiki.cgi' with your browser.

    (7) Go to 'AdminChangePassword' page and initialize admin password.

    (8) For further info...
        perldoc wikiman_ja.pl
        pod2html wikiman_ja.pl > wikiman_ja.html

AUTHOR

Hiroshi Yuki <hyuki@hyuki.com> http://www.hyuki.com/yukiwiki/

LICENSE

Copyright (C) 2000-2002 by Hiroshi Yuki.

This program is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

