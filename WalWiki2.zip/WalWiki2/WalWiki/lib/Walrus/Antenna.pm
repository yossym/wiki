package Walrus::Antenna;
use Yuki::RSS;

=head1 NAME

Walrus::Antenna - YukiWiki/WalWiki�p�̃A���e�i�iRSS/YukiWiki�`���̍X�V����́j���W���[��

=head1 SYNOPSIS

	use strict;
	use Walrus::Antenna;
	
	# step by step
	my @items = &parse_html($url, $type, $source [, $limit]);         # $source can be filename or filehandle
	my $rss   = &generate_rss($title, $url, $description, @items);    # requires Yuki::RSS
	my $html  = &generate_html(@items);
	
	# 1 step html generating
	my $html  = &process_html($url, $type, $source [, $limit]);       # $source can be filename or filehandle
	
	# generate rss
	my $rss   = &process_rss($title, $description, $url, $type, $source [, $limit]);    # requires Yuki::RSS

=head2 SYNOPSIS for testing

	perl Antenna.pm --antenna-test URL TYPE SOURCEFILE [LIMIT]

=head1 VERSION

=head2 0.1.1

Source can be file, gzipped file or filehandle instead of plain text file.

=head2 0.1.0

Initial release.

=cut

use lib '../';
use Time::Local;
use Data::Dumper;
use strict;
use vars qw($VERSION @EXPORT @EXPORT_OK @ISA);
require Exporter;
$VERSION      = '0.1.1';
@ISA          = qw(Exporter);
@EXPORT_OK    = qw(test process_html parse_html generate_html);
my $debugging = 0;
my %PARSER    = (
	'YukiWiki' => \&Walrus::Antenna::Parser::YukiWiki::parse_html,
	'RSS'      => \&Walrus::Antenna::Parser::RSS::parse_html,
);

&test if (@ARGV and $ARGV[0] == '--antenna-test' and @ARGV == 4 or @ARGV == 5);

sub test {
	$debugging = 1;
	my ($testfrag, $url, $type, $source, $limit) = @ARGV;
	print join("\n\t", '[test]', "url : $url", "type : $type", "source : $source", "limit : $limit")."\n" if ($debugging);
	my $html = &process_html($url, $type, $source, $limit);
	print "\n".$html;
}

sub process_html {
	my ($url, $type, $source, $limit) = @_;
	print join("\n\t", '[process_html]', "url : $url", "type : $type", "source : $source", "limit : $limit")."\n" if ($debugging);
	my @items = &parse_html($url, $type, $source, $limit);
	my $html  = &generate_html(@items);
	print "[process_html] result : ".length($html)." bytes.\n" if ($debugging);
	return $html;
}

sub process_rss {
	my ($title, $description, $url, $type, $source, $limit) = @_;
	print join("\n\t", '[process_rss]', "url : $url", "type : $type", "source : $source", "limit : $limit")."\n" if ($debugging);
	my @items = &parse_html($url, $type, $source, $limit);
	my $rss   = &generate_rss($title, $url, $description, @items);
	print "[process_rss] result : ".length($rss)." bytes.\n" if ($debugging);
	return $rss;
}

sub parse_html {
	my ($url, $type, $source, $limit) = @_;
	print join("\n\t", '[parse_html]', "url : $url", "type : $type", "source : $source", "limit : $limit")."\n" if ($debugging);
	my $handle = &generate_handle($source);
	return undef unless ($handle);
	# load parser module
	unless (defined($PARSER{$type})) {
		my $loader = "use Walrus::Antenna::Parser::${type};\n".
		             "\$PARSER{${type}} = \\\&Walrus::Antenna::Parser::${type}::parse_html;";
		eval $loader;
		print $@;
		unless (defined($PARSER{$type})) {
			print qq([parse_html] Can not load $type parser.\n) if ($debugging);
			return;
		}
	}
	# parse
	print qq([parse_html] parser : $PARSER{$type}\n) if ($debugging);
	my @items = &{$PARSER{$type}}($url, $handle, $limit);
	close $handle;
	# check fetch error
	if (not @items and $handle = &generate_handle($source)) {
		my $message = <$handle>;
		close $handle;
		if ($message =~ /^\[(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\] (\d+) : ([^\r\n]+)[\r\n]*$/) {
			push(@items, {'dc:date' => "$1T$2", 'title' => $3, 'description' => $4, 'link' => $url});
		}
	}
	return @items;
}

sub generate_html {
	my @items    = @_;
	my @results;
	print "[generate_html]\n".Dumper([@items]) if ($debugging);
	foreach my $item (@items) {
		my $limit_desc_length  = 100;
		my $limit_title_length = 60;
		# --- author ---
		my $author = ($item->{'dc:creater'}) ? qq( by <span class="author">$item->{'dc:creater'}</span>) : '';
		# --- date ---
		my $date = $item->{'dc:date'};
		$date = &convert_date($date);
		$date = ($date) ? qq(<span class="date">$date</span>) : '';
		# --- title ---
		my $title = ($item->{'title'}) ? $item->{'title'} : $item->{'description'};
		$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$title = &limitate_length($title, $limit_title_length);
		$title = ($title) ? qq(<span class="title">$title</span>) : '';
		# --- link ---
		my $link = ($item->{'link'}) ? $item->{'link'} : $item->{'about'};
		$title = qq(<a href="$link">$title</a>) if ($link);
		# --- description ---
		my $description = $item->{'description'};
		$description =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$description = &limitate_length($description, $limit_desc_length);
		$description = ($description) ? qq(<span class="description">$description</span>) : '';
		# ---result ---
		push(@results, "<li>${date}${title}${description}${author}</li>");
	}
	return unless (@results);
	return wantarray ? ('<ul>', @results, '</ul>') : "<ul>\n\t".join("\n\t", @results)."\n</ul>\n";
}

sub generate_rss {
	my ($title, $url, $description, @items) = @_;
	my $rss = new Yuki::RSS(
		version => '1.0',
		encoding => 'euc',
	);
	$rss->channel(
		title => $title,
		link  => $url,
		description => $description,
	);
	foreach my $item (@items) {
		unless ($item->{'dc:date'} =~ /^\d{4}(?:-\d{2}(?:-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d)?)?(:?Z|[+-]\d{2}:\d{2})?)?)?)?$/) {
			$item->{'dc:date'} = '';
		}
		$rss->add_item(%{$item});
	}
	print <<"EOD"
Content-type: text/xml

@{[$rss->as_string]}
EOD
}

sub generate_handle {
	my $source = shift;
	# set $handle as source file handle
	if (ref($source) eq 'GLOB') {
		return $source;
	} elsif (not -f $source) {
		print qq([generate_handle] Source file "$source" does not exist.\n) if ($debugging);
		return undef;
	} elsif ($source =~ /\.gz$/i) {
		unless ($_ = `which gzip`) {
			print qq([generate_handle] gzip command is not available for source file "$source".\n) if ($debugging);
			return undef;;
		}
		unless (open(IN, "gzip -cd $source |")) {
			print qq([generate_handle] Can not open source file "$source".\n) if ($debugging);
			return undef;;
		}
	} elsif (not open(IN, $source)) {
		print qq([generate_handle] Can not open source file "$source".\n) if ($debugging);
		return undef;;
	}
	return *IN;
}

sub convert_date {
	my $date = shift;
	if ($date =~ /^(\d{4})(?:-(\d{2})(?:-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d))?)?(Z|([+-]\d{2}):(\d{2}))?)?)?)?$/) {
		# w3m�`��(RSS�Ȃ�)���� "yyyy-mm-dd (wday) hh:mm:ss" �ւ̕ϊ�
		my ($year, $month, $day, $hour, $min, $sec, $wday) = ($1, ($2 ? $2 : 1), ($3 ? $3 : 1), $4, $5, $6);
		my $offset = (abs($8) * 60 + $9) * ($8 >= 0 ? 60 : -60) if ($7);
		my $time   = ($7) ? &Time::Local::timegm($sec, $min, $hour, $day, $month - 1, $year) - $offset
		                  : &Time::Local::timelocal($sec, $min, $hour, $day, $month - 1, $year) - $offset;
		($sec, $min, $hour, $day, $month, $year, $wday) = localtime($time);
		$wday = (qw(Sun Mon Tue Wed Thu Fri Sat))[$wday];
		$date = sprintf('%04d-%02d-%02d (%s) %02d:%02d:%02d', $year + 1900, $month + 1, $day, $wday, $hour, $min, $sec);
	} else {
		# w3m�`���ȊO�̌`���́A���t�A�����̐��`
		$date =~ s/^(\d+)[\.\/-](\d+)[\.\/-](\d+)/sprintf('%s-%02d-%02d', $1, $2, $3)/e;
		$date =~ s/(\d+):(\d+)(?::(\d+))?/sprintf('%02d:%02d:%02d', $1, $2, $3)/e;
	}
	return $date;
}

sub limitate_length {
	my ($text, $limit) = @_;
	return $text unless ($limit);
	return $text if ($limit >= length($text));
	for (my $length = $limit - 3; $length; $length--) {
		$text = substr($text, 0, $length);
		last unless ($text =~ /\x8F$/ or $text =~ tr/\x8E\xA1-\xFE// % 2 or $text =~ /&[^&;]*$/);
	}
	$text .= '...';
	return $text;
}

sub html_to_array {
	@_ = &xml_to_array($_[0], 1);
	return wantarray ? @_ : join('', @_);
}

sub xml_to_array {
	my $tag_regex_    = q{[^"'<>]*(?:"[^"]*"[^"'<>]*|'[^']*'[^"'<>]*)*(?:>|(?=<)|$(?!\n))}; #'}}}};
	my $comment_regex = '<!(?:--[^-]*-(?:[^-]+-)*?-(?:[^>-]*(?:-[^>-]+)*?)??)*(?:>|$(?!\n)|--.*$)';
	my $tag_regex     = qq{$comment_regex|<$tag_regex_};
	my $text_regex    = q{[^<]*};
	my $str           = shift(@_);
	my $html_mode     = shift(@_);
	my @result;
	while ($str =~ /($text_regex)($tag_regex)?/gso) {
		last if $1 eq '' and $2 eq '';
		push (@result, $1, $2);
		if ($html_mode and $2 =~ /^<(XMP|PLAINTEXT|SCRIPT)(?![0-9A-Za-z])/i) {
			$str =~ /(.*?)(?:<\/$1(?![0-9A-Za-z])$tag_regex_|$)/gsi;
			my $text_tmp = $1;
			$text_tmp =~ s/</&lt;/g;
			$text_tmp =~ s/>/&gt;/g;
			push (@result, $text_tmp);
		}
	}
	return wantarray ? @result : join('', @result);
}

package Walrus::Antenna::Parser::RSS;

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $rss = join('', <$handle>);
	my @parsed = &Walrus::Antenna::xml_to_array($rss);
	my @items;
	while (@parsed) {
		my $current = shift(@parsed);
		$current =~ s/^\s*(.*?)\s*$/$1/;
		if ($current =~ /^<item( rdf:about="(.+?)")?>$/i) {
			push @items, {};
			$items[$#items]->{'about'} = $2 if ($1);
			while (@parsed) {
				($current = shift(@parsed)) =~ s/^\s*(.*?)\s*$/$1/;
				last if ($current =~ /^<\/item>$/i);
				next unless ($current =~ /^<([^\/].*)>$/);
				$items[$#items]->{$1} = (@parsed) ? shift(@parsed) : undef;
			}
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

package Walrus::Antenna::Parser::YukiWiki;

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url =~ s/\?.+//;
	my @items;
	while (not eof($handle)) {
		my $item = <$handle>;
		next unless ($item =~ /<li> <span class="date">(.*?)<\/span> <a title=".*?" href="(.*?)">(.*?)<\/a>\s+.?\s*(.*)<\/li>/g);
		my ($date, $link, $title, $desc) = ($1, $2, $3, $4);
		$link  =~ s/^[^\?]*/$url/;
		$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$desc  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		push (@items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc});
		last if ($limit and @items >= $limit);
	}
	return @items;
}

1;
