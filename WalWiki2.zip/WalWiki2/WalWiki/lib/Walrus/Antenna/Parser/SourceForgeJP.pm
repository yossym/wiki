package Walrus::Antenna::Parser::SourceForgeJP;
use strict;

# SourceForge-ja�p Walrus::Antenna�v���O�C��
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://sourceforge.jp/projects/PROJECTNAME/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my @files = &parse_files($url, $handle, $limit);
	my @news  = &parse_news($url, $handle, $limit);
	my @items = sort {$b->{'dc:date'} cmp $a->{'dc:date'}} (@news, @files);
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

sub parse_files {
	my ($url, $handle, $limit) = @_;
	my $part_from = '<!-- New HTML Table (Latest File Releases) -->';
	my $part_till = '<!-- End HTML Table (Latest File Releases) -->';
	my $splitter  = '<TR bgcolor="#FFFFFF">';
	my $keyword   = '<TD bgcolor="#EAECEF">';
	my @items;
	my $html;
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	while (not eof($handle) and index($html,     $part_till) == -1) { $html .= <$handle>; }
	$html =~ s/\s+/ /g;
	$url = ($url =~ /^((https?|ftp):\/\/[^\/]+)/) ? $1 : '';
	foreach my $item (split($splitter, $html)) {
		next if (index($item, $keyword) == -1);
		my ($title, $desc, $date, $link) = (split(/<td[^<>]*>/i, $item))[1,2,3,5];
		$link = ($link =~ /<a href="(.+?)">Download<\/a>/) ? $url.$1 : '';
		($title, $desc, $date, $link) = map {s/<[^<>]*>//g; s/[\r\n]//g; s/^\s*(.+?)\s*$/$1/; $_} ($title, $desc, $date, $link);
		$date =~ s/ /T/;
		next unless ($title);
		push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>'[FILE] '.$title, 'description'=>$desc};
	}
	return @items;
}

sub parse_news {
	my ($url, $handle, $limit) = @_;
	my $part_from = '<!-- New HTML Table (Latest News) -->';
	my $part_till = '<!-- End HTML Table (Latest News) -->';
	my $splitter  = '<HR.+?>';
	my @items;
	my $html;
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	while (not eof($handle) and index($html,     $part_till) == -1) { $html .= <$handle>; }
	$url = ($url =~ /^((https?|ftp):\/\/[^\/]+)/) ? $1 : '';
	foreach my $item (split($splitter, $html)) {
		my ($link, $title)  = ($1, $2) if ($item =~ s/<A HREF="(.+?)"><strong>([^<>]+?)<\/strong><\/A>//i);
		my ($author, $date) = ($1, $2) if ($item =~ s/<i>(.+?) - (\d{4}-\d{2}-\d{2} \d{2}:\d{2})<\/I>//i);
		next unless ($title);
		($date, $title, $author, $link) = map {s/<[^<>]*>//g; s/[\r\n]//g; s/^\s*(.+?)\s*$/$1/; $_} ($date, $title, $author, $link);
		$date =~ s/ /T/;
		my $desc = ($author) ? "by $author" : '';
		push @items, {'dc:date'=>$date, 'link'=>"$url$link", 'title'=>'[NEWS] '.$title, 'description'=>$desc};
		last if ($limit and @items >= $limit);
	}
	return @items;
}

1;
