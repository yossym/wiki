package Walrus::Antenna::Parser::tDiary;
use strict;

# ==========================================================
# tDiary�p Walrus::Antenna�v���O�C��
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# ==========================================================

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url          =~ s/\?.+//;
	my $last_date = '';
	my $server    = ($url =~ /^((https?|ftp):\/\/[^\/]+)/)        ? $1 : '';
	my $directory = ($url =~ /^((https?|ftp):\/\/[^\/]+(.*\/)?)/) ? $1 : '';
	my @items     = ();
	my $item_from = '<div class="section">';
	my $item_to   = '</div>';
	my $html      = '';
	while (not eof($handle)) {
		$html    .= <$handle>;
		my $pos  = index($html, $item_from);
		next if ($pos == -1);
		$html = substr($html, $pos + length($item_from));
		$pos  = index($html, $item_to);
		while ($pos == -1 and not eof($handle)) {
			$html .= <$handle>;
			$pos   = index($html, $item_to);
		}
		my $item   = ($pos != -1) ? substr($html, 0, $pos)                 : $html;
		$html      = ($pos != -1) ? substr($html, $pos + length($item_to)) : '';
		$item      =~ s/\s+/ /g;
		next unless ($item =~ /<h3>(.+?)<\/h3>.*?(<p>.+?<\/p>)?/);
		my $title  = $1;
		next unless ($title =~ s/<a href="(.*?)".*?><span class="sanchor">.*?<\/span><\/a>//);
		my $link    = (substr($1, 0, 1) eq '/') ? $server.$1 : (substr($1, 0, 1) eq '.') ? $directory.$1 : $1;
		next unless ($link  =~ /(\d{4})(\d{2})(\d{2}).*?$/);
		my $date    = join('-', $1, $2, $3);
		my $dc_date = ($title =~ s/<span class="timestamp">(.+?)<\/span>//) ? "${date}T${1}+09:00" : $date;
		$title      =~ s/(<("([^"]|\\")*"|[^>])*>)//g;
		my $desc    = $1 if ($item =~ /<p>(.+?)<\/p>/);
		$desc       =~ s/(<("([^"]|\\")*"|[^>])*>)//g;
		push @items, {'dc:date'=>$dc_date, 'link'=>$link, 'title'=>$title, 'description' => $desc};
		last if ($limit and @items >= $limit and $date ne $last_date);
		$last_date = $date;
	}
	@items = sort {$b->{'link'} cmp $a->{'link'}} @items;
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

1;
