package Walrus::Antenna::Parser::ZaurusSoftwareIndex;
use strict;

# Zaurus Software Index�� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://killefiz.de/zaurus/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $part_from = '<b>Latest changes/additions:</b>';
	my $part_till = '</table>';
	my $from = '<tr class="';
	my $till = '</tr>';
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	my @items;
	my $article;
	while (not eof($handle)) {
		my $line = <$handle>;
		if (index($line, $part_till) != -1) {
			last;
		} elsif (index($line, $from) != -1) {
			$article = $line;
		} elsif (index($line, $till) != -1) {
			$article .= $line;
			$article =~ s/\s+/ /g;
			$article =~ s/\s*(<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>)\s*/$1/g;
			my ($link, $title, $desc, $date) = ($article =~ /<td[^>]*>.+?<\/td>/gi);
			$article = '';
			$link  = ($link  =~ /<a href='(.+?)'>/i)             ? $url.$1               : '';
			$title = ($title =~ /<a href='.+?'>(.+?)<\/a>/i)     ? $1                    : '';
			$date  = ($date  =~ /\((\d{2})\/(\d{2})\/(\d{4})\)/) ? join('-', $3, $1, $2) : '';
			$title =~ s/\s*<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>\s*//g;
			$desc  =~ s/\s*<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>\s*//g;
			next unless ($title);
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
		} elsif ($article) {
			$article .= $line;
		}
	}
	return @items;
}

1;
