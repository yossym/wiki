package Walrus::Antenna::Parser::IchiTokumei;
use strict;

# Linux�����륹�ѤΥ��եȥ�����ã�� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.geocities.co.jp/HeartLand/8249/SL-A300.html

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $part_from  = q(<h2> �������� </h2>);
	my $part_till  = q(</p>);
	my $content;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	while (not eof($handle) and index($content,  $part_till) == -1) { $content .= <$handle>; }
	$content =~ s/\s+/ /g;
	$content =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
	my @items;
	while ($content =~ s/<(p|br)>\((\d+)\.(\d+)\.(\d+)\)(.*?)<br>/<br>/) {
		my ($date, $title) = (sprintf('%04d-%02d-%02d', $2, $3, $4), $5);
		my $desc = $3 if ($title =~ s/^(.*?(\. |��))(.+)/$1/);
		my $link = $url;
		$title   =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$desc    =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
		last if ($limit and @items >= $limit);
	}
	return @items;
}

1;
