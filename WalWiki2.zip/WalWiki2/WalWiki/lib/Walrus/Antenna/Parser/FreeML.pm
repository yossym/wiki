package Walrus::Antenna::Parser::FreeML;
use strict;

# FreeML ���b�Z�[�W�y�[�W�p Walrus::Antenna�v���O�C��
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.freeml.com/ctrl/html/MessageListForm/???@freeml.com

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $part_from = '<table cellpadding=3 cellspacing=1 border=0 bgcolor="#FFFFFF" width="100%">';
	my $part_till = '</table>';
	my $from = ' <tr>';
	my $till = '</tr>';
	my @items;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	my $article;
	while (not eof($handle)) {
		my $line = <$handle>;
		last if (index($line, $part_till) != -1);
		if (index($line, $from) != -1) {
			$article = $line;
		} elsif (index($line, $till) != -1) {
			$article .= $line;
			$article =~ s/\s+/ /g;
			my ($title, $date, $link, $desc) = ($article =~ /<td[^>]*>.+?<\/td>/gi);
			$title = ($title =~ /<b>(\d+)<\/b>/) ? "[$1]" : '';
			if ($link =~ /<a href="(.+?)(;.+?)?">(.+?)<\/a>/) {
				$title .= " $3";
				$link   = 'http://www.freeml.com'.$1;
			} else {
				next;
			}
			$date = ($date =~ /<font size="-1">(.+?)<\/font>/) ? $1 : '';
			$desc = ($desc =~ /<font size="-1">(.+?)<\/font>/) ? $1 : '';
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			$article = '';
		} elsif ($article) {
			$article .= $line;
		}
	}
	@items = reverse(@items);
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

1;
