package Walrus::Antenna::Parser::MemAntenna;
use strict;

# ==========================================================
# mamantenna�� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4
#    by memn0ck <memn0ck@yahoo.co.jp>
# ==========================================================

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $base       = 'http://www.linuxdevices.com';
	my $last_year  = (localtime)[5] + 1900;
	my $last_month = (localtime)[4] + 1;
	my @items;
	while (not eof($handle)) {
		my $line = <$handle>;
		if ($line =~ /^(\d+)\/(\d+)\s(\d+)\:(\d+)\s<a href="(.+?)">(.+?)<\/a><br>/) {
			my ($month, $day, $hour, $min, $link, $title) = ($1, $2, $3, $4, $5, $6);
			my $year = ($month > $last_month) ? $last_year - 1 : $last_year;
			my $date = sprintf('%04d-%02d-%02dT%02d:%02d', $year, $month, $day, $hour, $min);
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description' => ''};
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

1;
