package Walrus::Antenna::Parser::Catsin;
use strict;

# catsin's WEBSITE�� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.geocities.co.jp/HeartLand/8249/SL-A300.html

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my @items;
	my $article;
	while (not eof($handle)){
		my $line = <$handle>;
		$line =~ s/\s+/ /g;
		$line =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
		if (index($line, '��') == 0) {
			$article .= $line;
		} elsif (index($line, '<br>') == 0 or index($line, '<hr>') != -1) {
			$article =~ /��(.+?)\[(\d+\/\d+\/\d+)\](.+)/;
			my ($title, $date, $desc) = ($1, $2, $3);
			my $link = $url;
			$date =~ s/\//-/g;
			$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			$desc  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			next unless ($title);
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
			$article = '';
		} elsif ($article) {
			$article .= $line;
		}
	}
	return @items;
}

1;
