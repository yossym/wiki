package Walrus::Antenna::Parser::ZauPoke;
use strict;

# ==========================================================
# �����륹�ݥå��ˤͤ�������� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.zaupoke.com/zaupoke_diary/
# ==========================================================

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $link = $url;
	my $splitter = '<IMG SRC="http://www.zaupoke.com/jpeg/LINE_7.JPG">';
	my $finisher = '<FORM METHOD="POST" ACTION="http://www.zaupoke.com/cgi-bin/zaupoke_diary.cgi">';
	my $article;
	while (index(<$handle>, $splitter) == -1 and not eof($handle)) { 1; }
	my @items;
	while (not eof($handle)) {
		my $line = <$handle>;
		last if (index($line, $finisher) != -1);
		if (index($line, $splitter) == -1) {
			$article .= $line;
			next;
		}
		my $item = &parse_article($article, $link);
		$article = '';
		push (@items, $item) if ($item);
		last if ($limit and @items >= $limit);
	}
	if ($article and (not $limit or @items < $limit)) {
		my $item = &parse_article($article, $link);
		push (@items, $item) if ($item);
	}
	return @items;
}

sub parse_article {
	my $article = shift;
	my $link    = shift;
	$article    =~ s/\x0D\x0A|\x0D|\x0A//g;
	$article    =~ s/\s+/ /g;
	my $dc_date = $1 if ($article =~ s/<B><FONT SIZE="3" COLOR="#9999CC">(.+?)<\/FONT><\/B>//i);
	$dc_date    = sprintf('%04d-%02d-%02d', @_) if ((@_ = ($dc_date =~ /\d+/g)) >= 3);
	my $title   = $1 if ($article =~ s/<B><FONT SIZE="3" COLOR="#666699">(.+?)<\/FONT><\/B>//i);
	my $desc    = $article;
	$desc       =~ s/(<("([^"]|\\")*"|[^>])*>)//g;
	my $item    = {'dc:date'=>$dc_date, 'link'=>$link, 'title'=>$title, 'description' => $desc};
	return $title ? $item : undef;
}

1;
