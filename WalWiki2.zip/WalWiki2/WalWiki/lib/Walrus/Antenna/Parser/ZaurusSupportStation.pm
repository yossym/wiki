package Walrus::Antenna::Parser::ZaurusSupportStation;
use strict;

# Zaurus Support Station�� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://zaurus.spacetown.ne.jp/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $part_from = '<!�������start------------------------->';
	my $part_till = '<!';
	my $from = '<li>';
	my $till = '<br>';
	$url     =~ s/[^\\\/]+$//;
	my $content;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	while (not eof($handle) and index($content,  $part_till) == -1) { $content .= <$handle>; }
	$content =~ s/\s+/ /g;
	my @items;
	while ((my $pos = index($content, $from)) != -1) {
		substr($content, 0, $pos, '');
		my $article = substr($content, 0, index($content, $till), '');
		my ($link, $title) = ($1, $2)     if ($article =~ s/<a href="([^""]+)"[^<>]*>(.+?)<\/a>//);
		my $date           = "20$1-$2-$3" if ($article =~ s/\((\d+)\/(\d+)\/(\d+)\)$//);
		my $desc           = $article;
		($title, $desc, $date, $link) = map {s/<[^<>]*>//g; s/[\r\n]//g; s/^\s*(.+?)\s*$/$1/; $_} ($title, $desc, $date, $link);
		next unless ($title);
		$title =~ s/\s*<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>\s*//g;
		$desc  =~ s/\s*<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>\s*//g;
		$link  = ($link =~ /^https?:\/\//)? $link : $url.$link;
		push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
		last if ($limit and @items >= $limit);
	}
	return @items;
}

1;
