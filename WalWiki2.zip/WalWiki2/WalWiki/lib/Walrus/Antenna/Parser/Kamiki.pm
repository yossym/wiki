package Walrus::Antenna::Parser::Kamiki;
use strict;

# ���ߤ������Zaurus SL-A300�� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://emmie.koka-in.org/~kensyu/zaurus/index.html

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url =~ s/[^\/]+$//;
	my $last_year  = (localtime)[5] + 1900;
	my $last_month = (localtime)[4] + 1;
	my $part_from  = q(<form name="log">);
	my $part_till  = q(</form>);
	my $content;
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	while (not eof($handle) and index($content,  $part_till) == -1) { $content .= <$handle>; }
	$content =~ s/\s+/ /g;
	$content =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
	my @items;
	while ($content =~ s/<option value="(.+?)"\s*>\s*(\d+)\/\s*(\d+)\s*(.*?)<(option|\/select)/<option/) {
		my ($link, $month, $day, $title) = ($1, $2, $3, $4);
		my $year = ($link =~ /\/(\d{4})(\d{2})(\d{2})/) ? $1 :
		           ($month > $last_month)               ? $last_year - 1 :
		           $last_year;
		$last_year  = $year;
		$last_month = $month;
		my $date    = sprintf('%04d-%02d-%02d', $year, $month, $day);
		$link       = $url.$link;
		$title      =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>undef};
		last if ($limit and @items >= $limit);
	}
	return @items;
}

1;
