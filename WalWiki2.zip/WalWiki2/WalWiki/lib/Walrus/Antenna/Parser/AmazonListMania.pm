package Walrus::Antenna::Parser::AmazonListMania;
use strict;

# ==========================================================
# Amazon�ꥹ�ȥޥ˥��� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# ==========================================================

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url = 'http://www.amazon.co.jp/exec/obidos/ASIN/isbn($1)/walrdigi-22';
	my @items     = ();
	my $item_from = "<table border=0 cellpadding=0 cellspacing=0 width='100%'>";
	my $html      = '';
	while (not eof($handle)) {
		$html = <$handle> while (not eof($handle) and index($html, $item_from) == -1);
		$html .= <$handle> while (not eof($handle) and index($html, '<b class=small>') == -1);
		my $pos = length($html);
		$html .= <$handle> while (not eof($handle) and index($html, '</table>', $pos) == -1);
		$html =~ s/\s*\n\s*//gs;
		$html =~ s/\s+/ /g;
		next unless ($html =~ /<b><a href="http:.*?\/ASIN\/(.*?)\/.*?">(.*?)<\/a><\/b>/);
		my $asin    = $1;
		my $title   = $2;
		my $price   = $1 if ($html =~ /<b class="small">���ʡ�<\/b><b class="price">(.+?)<\/b><br>/i);
		my $ship    = $1 if ($html =~ /<\/table><br>(.*?)<BR><\/font>/i);
		my $comment = $1 if ($html =~ /<td colspan=3 class=small><b class=small>.*?<\/b><br>(.*?)<\/td><\/tr>/i);
		$ship = "$1ȯ��" if ($ship =~ /(\Q24���ְ����\E|\Q2��3�������\E|\Q���٤�����\E)/);
		my $link    = $url;
		$link       =~ s/isbn\(\$1\)/$asin/g;
		my $desc    = ($price) ? " ($price��$ship) $comment" : " (���ʼ谷�ʤ�) $comment";
		$title      =~ s/(<("([^"]|\\")*"|[^>])*>)//g;
		$desc       =~ s/(<("([^"]|\\")*"|[^>])*>)//g;
		unshift(@items, {'link'=>$link, 'title'=>$title, 'description' => $desc});
		$html = '';
	}
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

1;
