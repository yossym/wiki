package Walrus::Antenna::Parser::AppTaizen;
use strict;

# SL-C7x0���ץꥱ������������� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.areanine.gr.jp/~nyano/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $base       = $url;
	$base          =~ s/[^\/]+$//;
	my $part_from  = '</P>';
	my $part_till  = '<P>[<A HREF="zakki2.html">���λ���</A>]</P>';
	my @items;
	my $date;
	while (not eof($handle)) {
		my $line = <$handle>;
		if ($line =~ /<dt><strong>.*?(\d{4})\/(\d{2})\/(\d{2})<\/strong><\/dt>/) {
			$date = sprintf('%04d-%02d-%02d', $1, $2, $3);
		} elsif ($line =~ /<dd>(.+?)<\/dd>/) {
			my $description = $1;
			my @bolds = ($description =~ /<b>(.*?)<\/b>/gi);
			my @links = ($description =~ /<a href="(.*?)".*?>.*?<\/a>/gi);
			my $title = (@bolds >= 2 and $bolds[1]) ? $bolds[1] : $bolds[0];
			$title    =~ s/<.*?>//g;
			my $link  = (@links >= 2 and $links[1]) ? $links[1] : $links[0];
			$link     = $base.$link unless ($link =~ /^https?:/);
			$description =~ s/<.*?>//g;
			push(@items, {
				'dc:date' => $date,
				'title'   => $title,
				'link'    => $link,
				'description' => $description
			});
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

1;
