package Walrus::Antenna::Parser::PocketGames;
use strict;

# pocketgames�� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://pocketgames.jp/index.php

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $base = $1 if ($url =~ /^(.+\/)/);
	my $from = '<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="3" WIDTH="100%" BGCOLOR="#cfdce3">';
	my @items;
	my $article;
	while (not eof($handle)) {
		my $line = <$handle>;
		if (index($line, $from) != -1) {
			if ($article) {
				my $item = &parse_article($article, $base);
				push(@items, $item) if ($item);
				last if ($limit and @items >= $limit);
			};
			$article = $line;
		} elsif ($article) {
			$article .= $line;
		}
	}
	if ($article and (not $limit or @items < $limit)) {
		my $item = &parse_article($article);
		push(@items, $item) if ($item);
	};
	return @items;
}

sub parse_article {
	my ($article, $base) = @_;
	$article =~ s/\s+/ /g;
	$article =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
	return undef unless ($article =~ /<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="3" WIDTH="100%" BGCOLOR="#cfdce3">(.*?)<TD ALIGN="left" VALIGN="top" CLASS="pn-normal">(.*?)<\/TD>/);
	my ($header, $desc)  = ($1, $2);
	my ($link, $title)   = ($1, $2) if ($header =~ /<a class="pn-title" href="(.*?)".*?>(.*?)<\/a>.*?/);
	my ($creator, $date) = ($1, $2) if ($header =~ /<font CLASS="pn-sub">Posted by: (.*?) on (.*?)<\/font>/);
	$link                = $base.$link;
	@_                   = ($date =~ /\d+/g);
	if (@_ == 5) { $date = sprintf('%04d-%02d-%02dT%02d:%02d:%02d+09:00', @_, 0); }
	else         {
		$date    =~ s/\s*-\s*/ /g;
		$date    =~ s/\//-/g;
	}
	$creator =~ s/\s*<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>\s*//g;
	$title   =~ s/\s*<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>\s*//g;
	$desc    =~ s/\s*<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>\s*//g;
	return undef unless ($title);
	return {'dc:date'=>$date, 'dc:Creator' => $creator, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
}

1;
