package Walrus::Antenna::Parser::HatenaAntenna;
use strict;

# ==========================================================
# �ϤƤʥ���ƥ��� Walrus::Antenna�ץ饰����
#    ver 0.4 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# ==========================================================

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my @items;
	my $article;
	while (not eof($handle)){
		my $line = <$handle>;
		if ($line =~ /^<li>(\d+\/\d+\/\d+ \d+:\d+:\d+) <a href="http:\/\/a.hatena.ne.jp\/go\?(.*?)">(.*?)<\/a>\s*(.*?)\s*$/) {
			my ($date, $link, $title, $desc) = ($1, $2, $3, $4);
			$date =~ s/\//-/g;
			$date =~ s/ /T/;
			$desc = $1 if ($desc =~ /^\s*(.+?)\s*$/);
			$line = <$handle>;
			$desc = $1 if ($line =~ /<p class="diff">(.*?)<\/p>/);
			$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			$desc  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			next unless ($title);
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

1;
