package Walrus::Antenna::Parser::LinuZauTeckKnow;
use strict;

# ��ʤ����ƥ��Υ��� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.areanine.gr.jp/~nyano/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $base       = "$1/" if ($url =~ /^(.+)\//);
	my $part_from  = '</P>';
	my $part_till  = '<P>[<A HREF="zakki2.html">���λ���</A>]</P>';
	my @items;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	my $item = {};
	while (not eof($handle)) {
		my $line = <$handle>;
		if (index($line, $part_till) != -1) {
			last;
		} elsif ($line =~ /<P><STRONG>(\d+)\/(\d+)\/(\d+)<\/STRONG><DL>/) {
			$item->{'dc:date'} = sprintf('%04d-%02d-%02d', $1, $2, $3);
		} elsif ($line =~ /<DT><A HREF="(.+?)" NAME=".+?">.*?<\/A> <B>(.+?)<\/B>/) {
			$item->{'link'}  = $1;
			$item->{'title'} = $2;
		} elsif ($line =~ /<DD>(.*[\S])/) {
			$item->{'description'} = $1;
			$item->{'description'}  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			$item->{'title'} =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			$item->{'link'}  = $base.$item->{'link'} unless ($item->{'link'} =~ /^https?:\/\//);
			push (@items, $item) if ($item->{'title'} and $item->{'dc:date'} and $item->{'link'});
			$item = { 'dc:date' => $item->{'dc:date'} };
		} elsif ($line =~ /<\/DL>/) {
			last if (@items >= $limit);
		}
	}
	@items = sort {$b->{'link'} cmp $a->{'link'}} @items;
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

1;
