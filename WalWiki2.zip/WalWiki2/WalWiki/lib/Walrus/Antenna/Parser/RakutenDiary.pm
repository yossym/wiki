package Walrus::Antenna::Parser::RakutenDiary;
use strict;

# ��ŷ�������������� Walrus::Antenna�ץ饰����
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://plaza.rakuten.co.jp/USERNAME/diaryall/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url           =~ s/^(https?:\/\/[^\/]+).+$/$1/i;
	my $part_from  = q(<!-- �����ޤ� -->);
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	my @items;
	while (not eof($handle)) {
		my $line = <$handle>;
		while ($line =~ s/<font size="-1">(\d{4})ǯ(\d{2})��(\d{2})�� <a href="(.+?)">(.+?)<\/a>\s*(:?<font color="red">.+?<\/font>)?(.+?)<br>//) {
			my $date = sprintf('%04d-%02d-%02d', $1, $2, $3);
			my ($link, $title, $desc) = ($4, $5, $6);
			$link    = $url.$link unless ($link =~ /^[a-z]+:\/\//);
			$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			$desc  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
			next unless ($title);
			push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}
1;
