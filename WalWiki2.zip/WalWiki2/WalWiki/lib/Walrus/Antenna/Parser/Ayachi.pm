package Walrus::Antenna::Parser::Ayachi;
use strict;

# ���s�̏��������p Walrus::Antenna�v���O�C��
#    ver 0.2 for WalWiki 2.0.5.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.ayati.com/index.html

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $content;
	my @items;
	# �X�V�����̏���
	my $part_from  = q(<ul>);
	my $part_till  = q(</ul>);
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	while (not eof($handle) and index($content,  $part_till) == -1) { $content .= <$handle>; }
	$content =~ s/�@/ /g;
	$content =~ s/�i/(/g;
	$content =~ s/�j/)/g;
	$content =~ s/\s+/ /g;
	$content =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
	while ($content =~ s/<li>(.+?)\((\d+?)\/(\d+?)\/(\d+?)\)<\/li>//) {
		my ($date, $title) = (sprintf('%04d-%02d-%02d', $4, $2, $3), $1);
		my $desc = $3 if ($title =~ s/^(.*?(\. |�B))(.+)/$1/);
		$title   =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$desc    =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		push @items, {'dc:date'=>$date, 'link'=>$url, 'title'=>$title, 'description'=>$desc};
	}
	# ���e�̏���
	$content = '';
	$part_from  = q(<h3>);
	$part_till  = q(<ul>);
	while (not eof($handle) and index(<$handle>, $part_from) == -1) { 1; }
	while (not eof($handle) and index($content,  $part_till) == -1) { $content .= <$handle>; }
	$content =~ s/�i/(/g;
	$content =~ s/�j/)/g;
	$content =~ s/�@/ /g;
	$content =~ s/\s+/ /g;
	$content =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
	while ($content =~ s/<A HREF="(.+?)">(.+?)<\/A>(\((.*?)\))?.*?<BR>//) {
		my ($link, $title, $desc) = ($1, $2, $4);
		my ($year, $month, $day) = ($desc =~ s/^(\d+)\/(\d+)\/(\d+)//) ? ($3, $1, $2) : ($desc =~ s/^(\d+)//) ? ($1, 1, 1) : (1980, 1, 1);
		my $date = sprintf('%04d-%02d-%02d', $year, $month, $day);
		$title   =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		$desc    =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
		push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
	}
	# ��������
	@items = sort {$b->{'dc:date'} cmp $a->{'dc:date'}} @items;
	@items = splice(@items, 0, $limit) if ($limit);
	return @items;
}

1;
