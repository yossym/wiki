package Walrus::Antenna::Parser::Header;
use strict;

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $html;
	my @items;
	while (not eof($handle)) {
		$html .= <$handle>;
		my $stored = '';
		my @parsed = &Walrus::Antenna::html_to_array($html);
		for (my $pos = 0; $pos < @parsed; $pos++) {
			if ($parsed[$pos] =~ /<h[2-6]\b.*>/) {
				if ($stored) {
					my $item = &parse_article($stored, $url);
					$stored  = '';
					push(@items, $item) if ($item);
					last if ($limit and @items >= $limit);
				}
				$stored .= $parsed[$pos];
			} elsif ($stored) {
				$stored .= $parsed[$pos];
			} elsif ($pos == $#parsed and $parsed[$pos] =~ /</) {
				$stored .= $parsed[$pos];
			}
		}
		$html = $stored;
		last if ($limit and @items >= $limit);
	}
	if ($html and (not $limit or @items < $limit)) {
		my $item = &parse_article($html, $url);
		push(@items, $item) if ($item);
	}
	return @items;
}

sub parse_article {
	my $article    = shift;
	my $link       = shift;
	my $desc_limit = 200;
	$article       =~ s/\s+/ /g;
	$article       =~ s/\s*(<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>)\s*/$1/g;
	return undef unless ($article =~ /<h[2-6]\b.*?>(.*?)<\/h[2-6]+>(.*)/i);
	my ($title, $desc) = ($1, $2);
	if ($title =~ /<a\b.*?\bname ?= ?("(""|[^"])*"|'(''|[^'])*'|[^<>\s]+)\b.*>/i) {
		my $name = $1;
		$name    =~ s/["']//g;
		$link    = $link.'#'.$name if ($name);
	}
	$title =~ s/<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>//g;
	$desc  =~ s/<(:?"(:?""|[^"])*"|'(:?''|[^'])*'|[^<>]+)>//g;
	$desc  = &Walrus::Antenna::limitate_length($desc, $desc_limit);
	return undef unless ($title);
	my $item = {'dc:date'=>undef, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
	return $item;
}

1;
