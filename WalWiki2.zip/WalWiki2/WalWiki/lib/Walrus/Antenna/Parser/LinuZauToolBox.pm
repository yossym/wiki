package Walrus::Antenna::Parser::LinuZauToolBox;
use strict;

# yakty's LinuZau Toolbox Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://yakty.s31.xrea.com/linuzau/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	$url =~ s/[^\/]+$//;
	my $part_from  = q(<h2>��������</h2>);
	my $part_till  = q(<h2>���</h2>);
	my $from       = q(<li>);
	my $till       = q(</li>);
	my $article;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	my @items;
	while (not eof($handle)) {
		my $line = <$handle>;
		last if (index($line, $part_till) != -1);
		if (index($line, $from) != -1) {
			$article = $line;
		} elsif ($article) {
			$article .= $line;
		}
		if (index($article, $till) != -1) {
			$article =~ s/\s+/ /g;
			$article =~ s/\s*(<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>)\s*/$1/g;
			while ($article =~ s/<li>(.*?)<a href="(.*?)">(.*?)<\/a>(.*?)<\/li>//i) {
				my ($date, $link, $title, $desc) = ($1, $2, $3, $4);
				$link  = $url.$link unless ($link =~ /^[a-z]+:\/\//);
				$title =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
				$desc  =~ s/<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>//g;
				$date  = sprintf('%04d-%02d-%02d', @_) if ((@_ = ($date =~ /\d+/g)) >= 3);
				next unless ($title);
				push @items, {'dc:date'=>$date, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
				last if ($limit and @items >= $limit);
			}
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

1;
