package Walrus::Antenna::Parser::LinuxDevices;
use strict;

# Linux Devices�� Walrus::Antenna�ץ饰����
#    ver 0.1 for WalWiki 2.0.5.wal.4
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.linuxdevices.com

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $base       = 'http://www.linuxdevices.com';
	my $part_from  = q(<font face='Arial,Helvetica'>News</font>);
	my $part_till  = q(<font face='Arial,Helvetica'>Articles</font>);
	my @items;
	while (index(<$handle>, $part_from) == -1 and not eof($handle)) { 1; }
	my $item = {};
	while (not eof($handle)) {
		my $line = <$handle>;
		if (index($line, $part_till) != -1) {
			last;
		} elsif ($line =~ s/<a href="(.*?)">(.*?)<\/a>(.*?)<\/td>//) {
			my ($link, $title, $desc) = ($1, $2, $3);
			$link  = $base.$link unless ($link =~ /^https?:\/\//);
			$title =~ s/\s*<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>\s*//g;
			$desc  =~ s/\s*<("(""|[^"])*"|'(''|[^'])*'|[^<>]+)>\s*//g;
			next unless ($title);
			push @items, {'dc:date'=>undef, 'link'=>$link, 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
		}
	}
	return @items;
}

1;
