package Walrus::Antenna::Parser::ActiveState;
use strict;

# ActiveState�p Walrus::Antenna�v���O�C��
#    ver 0.1 for WalWiki 2.0.4.wal.4.exp
#    by Makio Tsukamoto <walrus@digit.que.ne.jp>
# URL - http://www.activestate.com/Corporate/Communications/

sub parse_html {
	my ($url, $handle, $limit) = @_;
	my $from = '<!-- Start of Press Article -->';
	my $till = '<!-- End of Press Article -->';
	my @items;
	my $article;
	while (not eof($handle)){
		my $line = <$handle>;
		if (index($line, $from) != -1) {
			$article .= $line;
		} elsif (index($line, $till) != -1) {
			$article =~ s/\s+/ /g;
			next unless ($article =~ /^([^:]+): <b>(.+?)<\/b>.*?<br \/>(.*?)<a href="(.+)">More<\/a>/);
			my ($date, $title, $desc, $link) = map {s/<.+?>//g; s/[\r\n]//g; s/^\s*(.+?)\s*$/$1/; $_} @_ = ($1, $2, $3, $4);
			push @items, {'dc:date'=>$date, 'link'=>"$url/$link", 'title'=>$title, 'description'=>$desc};
			last if ($limit and @items >= $limit);
			$article = '';
		} elsif ($article) {
			$article .= $line;
		}
	}
	return @items;
}

1;
