package Walrus::Antenna::Cache;
use Data::Dumper;
use strict;
use HTTP::Lite;

=head1 NAME

Walrus::Antenna::Cache - File based database to cache web data.

=head1 SYNOPSYS

 # tieing normaly
 tie(%db, "Walrus::Antenna::Cache", $datadir);
 # or tieing with cache interval
 tie(%db, "Walrus::Antenna::Cache", $datadir,
 	'interval' => 30*60,                          # Cache interval (sec)
 	'proxy'    => 'http://proxy:8080',            # Proxy (default is $ENV{'HTTO_PROXY'}).
 	'debug'    => 0,                              # Debug mode on/off. (1 means on, default is off.)
 );
 
 # cache from url
 $db{$key} = $url;
 # cache from filepath
 $db{$key} = $filepath;
 
 # get cache file name
 my $file = $db{$key};

=cut

sub new { return shift->TIEHASH(@_); }

sub TIEHASH {
	my ($class, $dbname, %opt) = @_;
	my $interval  = ($opt{'interval'} and $opt{'interval'} =~ /^\d+$/) ? $opt{'interval'} : 0;
	my $proxy     = (defined($opt{'proxy'})) ? $opt{'proxy'} : $ENV{'HTTP_PROXY'};
	my $debugging = ($opt{'debug'}) ? $opt{'debug'} : 0;
	my $self = {
		dir       => $dbname,
		keys      => [],
		interval  => $interval,
		debugging => $debugging,
		proxy     => $proxy,
		jconv     => &create_jconv,
	};
	if (not -d $self->{dir}) {
		if (!mkdir($self->{dir}, 0777)) {
			print qq([Walrus::Antenna::Cache::TIEHASH] Can't make directory "$self->{dir}" : $!\n) if ($self->{debugging});
			return undef;
		}
	}
	return bless($self, $class);
}

sub STORE {
	my ($self, $key, $path) = @_;
	print qq([Walrus::Antenna::Cache::STORE] STORE("$key", "$path")\n) if ($self->{debugging} >= 2);
	my $file = &make_filename($self, $key);
	if ((not $self->{'interval'}) or (not -e $file) or ((stat($file))[9] < time - $self->{'interval'})) {
		if    ($path =~ /^https?:\/\//i) { $self->mirror($path, $file); }
		elsif (-f $path)                 { $self->copy($path, $file); }
		else {
			print qq([Walrus::Antenna::Cache::STORE] Specified path "$path" is invalid.\n) if ($self->{debugging});
			return undef;
		}
	}
	return $file if (-e $file);
	print qq([Walrus::Antenna::Cache::STORE] File "$file" for key "$key" does not existis.\n) if ($self->{debugging});
	return undef;
}

sub FETCH {
	my ($self, $key) = @_;
	print qq([Walrus::Antenna::Cache::FETCH] FETCH("$key")\n) if ($self->{debugging} >= 2);
	my $file = &make_filename($self, $key);
	return $file if (-e $file);
	print qq([Walrus::Antenna::Cache::FETCH] File "$file" for key "$key" does not existis.\n) if ($self->{debugging});
	return undef;

}

sub EXISTS {
	my ($self, $key) = @_;
	my $file = &make_filename($self, $key);
	return -e($file);
}

sub DELETE {
	my ($self, $key) = @_;
	my $file = &make_filename($self, $key);
	unlink $file;
	return delete $self->{$key};
}

sub FIRSTKEY {
	my ($self)    = @_;
	opendir(DIR, $self->{dir}) or die $self->{dir};
	my @keys      = grep { s/\.txt$// } readdir(DIR);
	@keys         = map { s/%([0-9A-Fa-f][0-9A-Fa-f])/pack('H2', $1)/eg } @keys;
	@keys         = sort(@keys);
	$self->{keys} = [@keys];
	return shift @{$self->{keys}};
}

sub NEXTKEY {
	my ($self) = @_;
	return shift @{$self->{keys}};
}

sub make_filename {
	my ($self, $key) = @_;
	$key =~ s/([^a-zA-Z0-9_-])/'%'.unpack('H2', $1)/eg;
	return $self->{dir} . "/$key.txt";
}

sub copy {
	my ($self, $source, $file) = @_;
	print qq([Walrus::Antenna::Cache::copy] mirror("$source", "$file")\n) if ($self->{debugging} >= 2);
	my $temp = $file.'.copy';
	unless (-f $source) {
		print qq([Walrus::Antenna::Cache::copy] Source file "$source" does not existis.\n) if ($self->{debugging});
		return undef;
	}
	unless (open(IN, $source)) {
		print qq([Walrus::Antenna::Cache::copy] Can't open source file "$source".\n) if ($self->{debugging});
		return undef;
	}
	unless (open(OUT, ">$temp")) {
		print qq([Walrus::Antenna::Cache::copy] Can't open temporary file "$temp".\n) if ($self->{debugging});
		return undef;
	}
	while (not eof(IN)) {
		my $line = <IN>;
		$line =~ s/\x0d\x0a|\x0d|\x0a/\n/g;
		&{$self->{'jconv'}}(\$line, 'euc');
		print OUT $line;
	}
	close OUT;
	close IN;
	my $result = rename $temp, $file;
	return 1 if ($result);
	print qq([Walrus::Antenna::Cache::copy] Can't rename "$temp" to "file".\n) if ($self->{debugging});
	unlink $temp;
	return undef;
}

sub mirror {
	my ($self, $url, $file, $moved) = @_;
	print qq([Walrus::Antenna::Cache::mirror] mirror("$url", "$file")\n) if ($self->{debugging} >= 2);
	unless ($url) {
		print qq([Walrus::Antenna::Cache::mirror] URL must specified.\n) if ($self->{debugging});
		return undef;
	}
	unless ($file) {
		print qq([Walrus::Antenna::Cache::mirror] Filename must specified.\n) if ($self->{debugging});
		return undef;
	}
	# make value of 'If-Modified-Since'
	my $modified = undef;
	if (-e $file) {
		my @days_of_week    = qw(Sun Mon Tue Wed Thu Fri Sat);
		my @monthes_of_year = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
		my $time  = (stat($file))[9];
		my ($sec, $min, $hour, $mday, $mon, $year, $wday) = gmtime($time);
		$modified = sprintf(
			"%s, %02d %s %04d %02d:%02d:%02d GMT",
			$days_of_week[$wday], $mday, $monthes_of_year[$mon], $year+1900,
			$hour, $min, $sec
		);
	}
	# process fetch
	my $writer = sub {
		my ($self, $dataref, $cbargs) = @_;
		print $cbargs $$dataref;
		return undef;
	};
	my $temp   = $file.'.mirror';
	unless (open(IN, ">$temp")) {
		print qq([Walrus::Antenna::Cache::mirror] Can't open temporary file "$temp".\n) if ($self->{debugging});
		return undef;
	}
	my $handle = *IN;
	binmode $handle;
	my $http = new HTTP::Lite;
	$http->proxy($self->{'proxy'}) if ($self->{'proxy'});
	$http->add_req_header('If-Modified-Since', $modified) if ($modified);
	my $status = $http->request($url, $writer, $handle) or return undef;
	@_         = localtime;
	my $result = sprintf("[%04d-%02d-%02d %02d:%02d:%02d] %s : %s\n", $_[5]+1900, $_[4]+1, $_[3], $_[2], $_[1], $_[0], $status, $http->status_message);
	if ($status == 200 and -f $temp and -s $temp) {
		close $handle;
		print qq([Walrus::Antenna::Cache::mirror] copy "$temp" to "$file"\n) if ($self->{debugging} >= 2);
		$self->copy($temp, $file);
	} elsif ($status == 302) {
		close $handle;
		$moved++;
		if ($moved < 5) {
			foreach ($http->headers_array) {
				if (/Location:\s*(http:\/\/\S+)/) {
					$self->mirror($1, $file, $moved);
					last;
				}
			}
		}
	} elsif ($status == 304 and -e $file and (stat($temp))[9]) {
		close $handle;
		print qq([Walrus::Antenna::Cache::mirror] touch "$file"\n) if ($self->{debugging} >= 2);
		if (my $touch = `which touch`) { system($touch $file); }
		else                           { $self->copy($temp, $file); }
	} else {
		printf $handle $result;
		close $handle;
		print qq([Walrus::Antenna::Cache::mirror] result : $result\n) if ($self->{debugging} and $status != 200 and $status != 304);
		print qq([Walrus::Antenna::Cache::mirror] copy "$temp" to "$file"\n) if ($self->{debugging} >= 2);
		$self->copy($temp, $file);
	}
	if (-f $temp) {
		print qq([Walrus::Antenna::Cache::mirror] unlink "$temp"\n) if ($self->{debugging} >= 2);
		unlink($temp);
	}
	return $file;
}

sub create_jconv {
	eval 'use Jcode;';
	return \&Jcode::convert unless ($@);
	eval q(require 'jcode.pl';);
	return \&jcode::convert unless ($@);
	return sub { return $_[0]; }
}

1;
